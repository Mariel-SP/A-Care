package com.tarea.a_care_practica;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.IllegalFormatCodePointException;

public class InicioSesionAnahuac extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion_anahuac);

        EditText userAnahuac = (EditText) findViewById(R.id.txtCorreoAnahuac);
        EditText contraAnahuac = (EditText) findViewById(R.id.txtPasswordAnahuac);

        Button btnIniciarSesion = (Button) findViewById(R.id.btnIniciarS_1);

        String Correo = "userAnahuac@mail.com";
        String Contra = "adminAnahuac1";

        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (userAnahuac.getText().toString().equals(Correo) && contraAnahuac.getText().toString().equals(Contra)){
                    //Inicio de sesión correcto.
                    Toast.makeText(InicioSesionAnahuac.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                    ResponderCuestionarioDiario(view);
                }
                else{
                    //Inicio de sesión incorrecto.
                    Toast.makeText(InicioSesionAnahuac.this, "Inicio de sesión fallido, intente otra vez", Toast.LENGTH_SHORT).show();
                    userAnahuac.setText("");
                    contraAnahuac.setText("");
                }
            }
        });
    }

    public void RegresarMain(View view){
        Intent activity_principal = new Intent(this, MainActivity.class);
        startActivity(activity_principal);
    }

    public void ResponderCuestionarioDiario(View view){
        Intent cuestionarioDiario = new Intent(this, ExplicacionCuestionarioDiario.class);
        startActivity(cuestionarioDiario);
    }
}